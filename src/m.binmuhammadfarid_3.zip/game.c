//---------------------------------------------------------
// file:	game.c
// author:	Muhammad Ibnu Khalis Bin Muhammad Farid
// email:	[m.binmuhammadfarid@digipen.edu]
//
// brief:	game_state after pressing "play" in mainmenu
//		
//
// Copyright © 2026 DigiPen, All rights reserved.
//---------------------------------------------------------


#include "cprocessing.h"
#include "mainmenu.h"
#include "game.h"
#include "utils.h"
#include <stdio.h>


float p_x;
float p_y;
float r_x;
float r_y;
float r_w;
float r_h;
float dt;
float h_s;
float p_s;

void Game_Init(void)
{
	p_x = 800.0f;
	p_y = 450.0f;
	r_x = 150.0f;
	r_y = 50.0f;
	r_w = 1300.0f;
	r_h = 50.0f;
	dt = CP_System_GetDt();
	h_s = 150.0f;
	p_s = 300.0f;

}


void Game_Update(void)
{
	CP_Graphics_ClearBackground(CP_Color_Create(200, 200, 200, 255));

	CP_Graphics_DrawCircle(400.0f, 450.0f, 400.0f);
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
	CP_Graphics_DrawCircle(1200.0f, 450.0f, 400.0f);
	CP_Settings_Fill(CP_Color_Create(255, 102, 255, 255));
	CP_Graphics_DrawCircle(p_x, p_y, 120.0f);
	CP_Settings_Fill(CP_Color_Create(152, 15, 15, 255));
	CP_Settings_RectMode(CP_POSITION_CORNER);
	CP_Graphics_DrawRect(150.0f, 50.0f, 1300.0f, 50.0f);
	CP_Settings_Fill(CP_Color_Create(255, 50, 50, 255));
	CP_Graphics_DrawRect(r_x, r_y, r_w, r_h);
	CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
	CP_Settings_Fill(CP_Color_Create(255, 50, 50, 255));

	if (CP_Input_KeyDown(KEY_Q))
	{
		CP_Engine_SetNextGameState(Main_Menu_Init, Main_Menu_Update, Main_Menu_Exit);
	}

	for (int i = 0; i < 10; i++)
	{
		if (r_w > i * 130.0f)
		{
			CP_Graphics_DrawRect(
				150.0f + i * 137.333f,
				150.0f,
				60.0f,
				50.0f
			);
		}
	}

	if (CP_Input_KeyDown(KEY_W))
	{
		p_y -= p_s * dt;


	}
	if (CP_Input_KeyDown(KEY_A))
	{
		p_x -= p_s * dt;

	}
	if (CP_Input_KeyDown(KEY_S))
	{
		p_y += p_s * dt;

	}
	if (CP_Input_KeyDown(KEY_D))
	{
		p_x += p_s * dt;

	}
	if (r_w <= 1300 && r_w >= 0)
	{
		if (AreCirclesIntersecting(p_x, p_y, 60.0f, 1200.0f, 450.0f, 200.0f))
		{
			r_w -= h_s * dt;
		}
		if (AreCirclesIntersecting(p_x, p_y, 60.0f, 400.0f, 450.0f, 200.0f))
		{
			r_w += h_s * dt;
		}
	}
	if (r_w > 1300)
	{
		r_w = 1300;
	}
	if (r_w < 0)
	{
		r_w = 0;
	}
}
void Game_Exit(void)
{
}