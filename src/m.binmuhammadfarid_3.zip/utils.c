//---------------------------------------------------------
// file:	utils.c
// author:	Muhammad Ibnu Khalis Bin Muhammad Farid
// email:	[m.binmuhammadfarid@digipen.edu]
//
// brief:	definition of functions
//		
//
// Copyright © 2026 DigiPen, All rights reserved.
//---------------------------------------------------------

#include <math.h>
#include "cprocessing.h"
#include "utils.h"
#include "game.h"

int IsAreaClicked(float area_center_x, float area_center_y, float area_width, float area_height, float click_x, float click_y)
{
    float left = area_center_x - area_width / 2.0f;
    float right = area_center_x + area_width / 2.0f;
    float top = area_center_y - area_height / 2.0f;
    float bottom = area_center_y + area_height / 2.0f;
    CP_Settings_Fill(CP_Color_Create(255, 153, 153, 255));

    if ((click_x >= left && click_x <= right) && (click_y >= top && click_y <= bottom))
    {

        CP_Settings_Fill(CP_Color_Create(255, 200, 200, 255));
        if (CP_Input_MouseTriggered(MOUSE_BUTTON_LEFT))
        {
            return 1;
        }
    }
    return 0;
}

int IsCircleClicked(float circle_center_x, float circle_center_y, float diameter, float click_x, float click_y)
{
    float radius = diameter / 2.0f;
    float left = circle_center_x - radius;
    float right = circle_center_x + radius;
    float top = circle_center_y - radius;
    float bottom = circle_center_y + radius;

    if ((click_x >= left && click_x <= right) && (click_y >= top && click_y <= bottom))
    {
        if (CP_Input_MouseTriggered(MOUSE_BUTTON_LEFT))
        {
            return 1;
        }

    }
    return 0;
}

int AreCirclesIntersecting(float c1_x, float c1_y, float r1, float c2_x, float c2_y, float r2)
{
    float dx = c2_x - c1_x;
    float dy = c2_y - c1_y;

    float distance = sqrtf(dx * dx + dy * dy);

    if (distance <= r1 + r2)
    {
        return 1;
    }

    return 0;
}